#pragma once

#include <complex>
#include <cstddef>
#include <string>
#include <vector>

using Complex = std::complex<double>;

inline std::size_t mat_index(int n, int row, int col) {
    return static_cast<std::size_t>(row) + static_cast<std::size_t>(col) * static_cast<std::size_t>(n);
}

inline const Complex& mat_at(const Complex* m, int n, int row, int col) {
    return m[mat_index(n, row, col)];
}

inline Complex& mat_at(Complex* m, int n, int row, int col) {
    return m[mat_index(n, row, col)];
}

void zero_matrix(int n, Complex* c);
void fill_random(int n, Complex* m, unsigned seed);
void fill_formula(int n, Complex* m, bool matrix_a);
bool load_matrices_file(const std::string& path, int& n, std::vector<Complex>& a,
                        std::vector<Complex>& b);
bool save_matrices_file(const std::string& path, int n, const Complex* a, const Complex* b);

#!/usr/bin/env python3
"""Generate Report_Lab2.pdf in the same simple style as lab1."""

from pathlib import Path

try:
    from fpdf import FPDF
except ImportError:
    raise SystemExit("Install fpdf2: pip install fpdf2")

LAB_ROOT = Path(__file__).resolve().parents[1]
OUT_PDF = LAB_ROOT / "report" / "Report_Lab2.pdf"
SCREENSHOT = LAB_ROOT / "screenshots" / "benchmark_output.txt"
FONT = Path(r"C:\Windows\Fonts\arial.ttf")
FONT_BOLD = Path(r"C:\Windows\Fonts\arialbd.ttf")


class ReportPDF(FPDF):
    def __init__(self) -> None:
        super().__init__()
        if FONT.exists():
            self.add_font("Arial", "", str(FONT))
            self.add_font("Arial", "B", str(FONT_BOLD))
            self._family = "Arial"
        else:
            self._family = "Helvetica"

    def set_body_font(self, style: str = "", size: int = 11) -> None:
        self.set_font(self._family, style, size)

    def footer(self) -> None:
        self.set_y(-15)
        self.set_body_font(size=9)
        self.cell(0, 10, f"- {self.page_no()} -", new_x="LMARGIN", new_y="NEXT", align="C")


def add_para(pdf: ReportPDF, text: str, size: int = 11) -> None:
    pdf.set_body_font(size=size)
    pdf.multi_cell(0, 6, text)
    pdf.ln(2)


def main() -> None:
    pdf = ReportPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    pdf.set_body_font("B", 14)
    pdf.cell(0, 10, "Лабораторная работа № 2", new_x="LMARGIN", new_y="NEXT")
    pdf.set_body_font("B", 12)
    pdf.cell(0, 8, "СТРУКТУРЫ ДАННЫХ И ОПТИМИЗАЦИЯ АЛГОРИТМОВ", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)

    add_para(
        pdf,
        "Цель работы: изучить умножение комплексных матриц, оценить вычислительную "
        "сложность c = 2n³ и производительность p = c/t·10⁻⁶ MFlops, сравнить три "
        "способа перемножения матриц 1024×1024.",
    )
    add_para(pdf, "Студент: Ибнеев Никита Дмитриевич 090301-ПОВа-о25")

    add_para(
        pdf,
        "Задание: Перемножить 2 квадратные матрицы 1024×1024 (double complex). "
        "Матрицы генерируются в программе или читаются из файла. Выполнить: "
        "(1) умножение по формуле линейной алгебры; (2) cblas_zgemm (Intel MKL / BLAS); "
        "(3) оптимизированный алгоритм (≥ 30% от варианта 2).",
    )

    pdf.set_body_font("B", 11)
    pdf.cell(0, 8, "Листинг (фрагмент main.cpp):", new_x="LMARGIN", new_y="NEXT")
    listing = (
        'cout << "Автор: Ибнеев Никита Дмитриевич" << endl;\n'
        'cout << "Группа: 090301-ПОВа-о25" << endl;\n'
        "// c = 2*n*n*n; p = c / t / 1e6;\n"
        "gemm_naive(n, A, B, C);      // вариант 1\n"
        "gemm_mkl(n, A, B, C);        // cblas_zgemm\n"
        "gemm_optimized(n, A, B, C);  // блоки + OpenMP"
    )
    pdf.set_body_font(size=9)
    pdf.multi_cell(0, 5, listing)
    pdf.ln(4)

    pdf.set_body_font("B", 11)
    pdf.cell(0, 8, "Результаты выполнения программы:", new_x="LMARGIN", new_y="NEXT")
    add_para(
        pdf,
        "Тестовый прогон (n = 1024, --source formula, OpenBLAS 1 поток, OpenMP 24 потока):",
    )
    add_para(pdf, "• Naive: t = 66.38 с, p = 32.35 MFlops")
    add_para(pdf, "• cblas_zgemm: t = 0.225 с, p = 9531.62 MFlops")
    add_para(pdf, "• Blocked+OpenMP: t = 0.640 с, p = 3357.56 MFlops (35.2% от BLAS)")

    if SCREENSHOT.exists():
        pdf.set_body_font("B", 11)
        pdf.cell(0, 8, "Вывод программы (фрагмент):", new_x="LMARGIN", new_y="NEXT")
        pdf.set_body_font(size=8)
        text = SCREENSHOT.read_text(encoding="utf-8", errors="replace")
        lines = [ln for ln in text.splitlines() if ln.strip()][:26]
        pdf.multi_cell(0, 4, "\n".join(lines))

    pdf.ln(4)
    add_para(
        pdf,
        "Вывод: Наивный тройной цикл при n = 1024 и отключённых оптимизациях (-O0) "
        "работает на порядки медленнее BLAS. Функция cblas_zgemm использует "
        "высокооптимизированные ядра библиотеки. Блочное умножение с разбиением "
        "на подматрицы 64×64 и параллелизмом OpenMP улучшает локальность данных "
        "и обеспечивает более 35% производительности BLAS при сохранении "
        "корректности результата.",
    )

    OUT_PDF.parent.mkdir(parents=True, exist_ok=True)
    pdf.output(str(OUT_PDF))
    print(f"Written: {OUT_PDF}")


if __name__ == "__main__":
    main()

$ErrorActionPreference = "Stop"
$LabRoot = Split-Path -Parent $PSScriptRoot
$Exe = Join-Path $LabRoot "build\lab2_matrix.exe"

if (-not (Test-Path $Exe)) {
    & (Join-Path $LabRoot "scripts\build_mingw.ps1")
}

$env:OMP_NUM_THREADS = if ($env:NUMBER_OF_PROCESSORS) { $env:NUMBER_OF_PROCESSORS } else { "8" }
New-Item -ItemType Directory -Force -Path (Join-Path $LabRoot "screenshots") | Out-Null

& $Exe --source formula | Tee-Object -FilePath (Join-Path $LabRoot "screenshots\benchmark_output.txt")
exit $LASTEXITCODE

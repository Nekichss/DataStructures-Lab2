#include "matrix.hpp"

#include <cmath>
#include <fstream>
#include <random>

void zero_matrix(int n, Complex* c) {
    const std::size_t count = static_cast<std::size_t>(n) * static_cast<std::size_t>(n);
    for (std::size_t i = 0; i < count; ++i) {
        c[i] = Complex(0.0, 0.0);
    }
}

void fill_random(int n, Complex* m, unsigned seed) {
    std::mt19937 rng(seed);
    std::uniform_real_distribution<double> dist(-1.0, 1.0);
    const std::size_t count = static_cast<std::size_t>(n) * static_cast<std::size_t>(n);
    for (std::size_t i = 0; i < count; ++i) {
        m[i] = Complex(dist(rng), dist(rng));
    }
}

void fill_formula(int n, Complex* m, bool matrix_a) {
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            const double base = static_cast<double>(i + j + 1);
            const double imag_part = matrix_a ? static_cast<double>(i) * 0.01
                                              : static_cast<double>(j) * 0.01;
            mat_at(m, n, i, j) = Complex(base * 0.001, imag_part);
        }
    }
}

bool load_matrices_file(const std::string& path, int& n, std::vector<Complex>& a,
                        std::vector<Complex>& b) {
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        return false;
    }

    int file_n = 0;
    in.read(reinterpret_cast<char*>(&file_n), sizeof(file_n));
    if (!in || file_n <= 0) {
        return false;
    }

    n = file_n;
    const std::size_t count = static_cast<std::size_t>(n) * static_cast<std::size_t>(n);
    a.resize(count);
    b.resize(count);

    in.read(reinterpret_cast<char*>(a.data()), static_cast<std::streamsize>(count * sizeof(Complex)));
    in.read(reinterpret_cast<char*>(b.data()), static_cast<std::streamsize>(count * sizeof(Complex)));
    return static_cast<bool>(in);
}

bool save_matrices_file(const std::string& path, int n, const Complex* a, const Complex* b) {
    std::ofstream out(path, std::ios::binary);
    if (!out) {
        return false;
    }

    out.write(reinterpret_cast<const char*>(&n), sizeof(n));
    const std::size_t count = static_cast<std::size_t>(n) * static_cast<std::size_t>(n);
    out.write(reinterpret_cast<const char*>(a), static_cast<std::streamsize>(count * sizeof(Complex)));
    out.write(reinterpret_cast<const char*>(b), static_cast<std::streamsize>(count * sizeof(Complex)));
    return static_cast<bool>(out);
}

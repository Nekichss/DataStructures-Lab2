#include "gemm.hpp"
#include "matrix.hpp"

#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <cstdint>
#include <limits>
#include <string>
#include <vector>

#if defined(_WIN32) && !defined(LAB2_USE_MKL)
extern "C" void openblas_set_num_threads(int num_threads);
#endif

namespace {
constexpr int kDefaultN = 1024;
constexpr int kWarmupRuns = 2;
constexpr int kTimedRuns = 5;

void print_author() {
    std::cout << "Автор: Ибнеев Никита Дмитриевич\n";
    std::cout << "Группа: 090301-ПОВа-о25\n";
    std::cout << "--------------------------------\n";
}

void print_usage() {
    std::cout << "Использование: lab2_matrix [--n N] [--source random|formula|file] "
                 "[--file path] [--save path] [--verify-only]\n";
}

long long flop_count(int n) {
    const long long nn = static_cast<long long>(n);
    return 2LL * nn * nn * nn;
}

double measure_seconds(void (*gemm_fn)(int, const Complex*, const Complex*, Complex*), int n,
                       const Complex* a, const Complex* b, Complex* c) {
    for (int w = 0; w < kWarmupRuns; ++w) {
        gemm_fn(n, a, b, c);
    }

    double best = std::numeric_limits<double>::max();
    for (int run = 0; run < kTimedRuns; ++run) {
        zero_matrix(n, c);
        const auto t0 = std::chrono::high_resolution_clock::now();
        gemm_fn(n, a, b, c);
        const auto t1 = std::chrono::high_resolution_clock::now();
        const double sec =
            std::chrono::duration<double>(t1 - t0).count();
        if (sec < best) {
            best = sec;
        }
    }
    return best;
}

}  // namespace

int main(int argc, char** argv) {
    print_author();

    int n = kDefaultN;
    std::string source = "random";
    std::string file_path;
    std::string save_path;
    bool verify_only = false;
    bool skip_naive = false;

    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        if (arg == "--n" && i + 1 < argc) {
            n = std::atoi(argv[++i]);
        } else if (arg == "--source" && i + 1 < argc) {
            source = argv[++i];
        } else if (arg == "--file" && i + 1 < argc) {
            file_path = argv[++i];
        } else if (arg == "--save" && i + 1 < argc) {
            save_path = argv[++i];
        } else if (arg == "--verify-only") {
            verify_only = true;
        } else if (arg == "--skip-naive") {
            skip_naive = true;
        } else if (arg == "--help") {
            print_usage();
            return 0;
        } else {
            std::cerr << "Неизвестный аргумент: " << arg << "\n";
            print_usage();
            return 1;
        }
    }

    if (n <= 0) {
        std::cerr << "Размер матрицы должен быть положительным.\n";
        return 1;
    }

    std::vector<Complex> a;
    std::vector<Complex> b;
    const std::size_t count = static_cast<std::size_t>(n) * static_cast<std::size_t>(n);
    a.resize(count);
    b.resize(count);

    if (source == "file") {
        if (file_path.empty()) {
            std::cerr << "Для --source file укажите --file path\n";
            return 1;
        }
        int file_n = 0;
        if (!load_matrices_file(file_path, file_n, a, b)) {
            std::cerr << "Не удалось прочитать файл: " << file_path << "\n";
            return 1;
        }
        n = file_n;
        a.resize(static_cast<std::size_t>(n) * static_cast<std::size_t>(n));
        b.resize(static_cast<std::size_t>(n) * static_cast<std::size_t>(n));
    } else if (source == "formula") {
        fill_formula(n, a.data(), true);
        fill_formula(n, b.data(), false);
    } else if (source == "random") {
        fill_random(n, a.data(), 42u);
        fill_random(n, b.data(), 43u);
    } else {
        std::cerr << "Неизвестный источник: " << source << "\n";
        return 1;
    }

    if (!save_path.empty()) {
        if (!save_matrices_file(save_path, n, a.data(), b.data())) {
            std::cerr << "Не удалось сохранить матрицы в " << save_path << "\n";
            return 1;
        }
        std::cout << "Матрицы сохранены: " << save_path << "\n";
    }

    std::vector<Complex> c_naive(count);
    std::vector<Complex> c_mkl(count);
    std::vector<Complex> c_opt(count);

    std::cout << "Размер матриц: " << n << " x " << n << "\n";
    std::cout << "Источник данных: " << source << "\n";
    std::cout << std::fixed << std::setprecision(6);

    const int verify_n = (n > 128) ? 128 : n;
    std::vector<Complex> va(static_cast<std::size_t>(verify_n) * static_cast<std::size_t>(verify_n));
    std::vector<Complex> vb(static_cast<std::size_t>(verify_n) * static_cast<std::size_t>(verify_n));
    const std::size_t verify_count =
        static_cast<std::size_t>(verify_n) * static_cast<std::size_t>(verify_n);
    std::vector<Complex> vn(verify_count);
    std::vector<Complex> vm(verify_count);
    std::vector<Complex> vo(verify_count);

    fill_formula(verify_n, va.data(), true);
    fill_formula(verify_n, vb.data(), false);
    gemm_naive(verify_n, va.data(), vb.data(), vn.data());
    gemm_mkl(verify_n, va.data(), vb.data(), vm.data());
    gemm_optimized(verify_n, va.data(), vb.data(), vo.data());

    const double diff_naive_mkl = max_diff(verify_n, vn.data(), vm.data());
    const double diff_opt_mkl = max_diff(verify_n, vo.data(), vm.data());
    std::cout << "Проверка (n=" << verify_n << "): |C_naive - C_mkl|_max = " << diff_naive_mkl
              << ", |C_opt - C_mkl|_max = " << diff_opt_mkl << "\n";

    if (verify_only) {
        return (diff_naive_mkl < 1e-8 && diff_opt_mkl < 1e-8) ? 0 : 2;
    }

    const long long flops = flop_count(n);
    std::cout << "Оценка сложности: c = 2*n^3 = " << flops << " операций\n\n";

    double t_naive = 0.0;
    double mflops_naive = 0.0;
    if (!skip_naive) {
        std::cout << "--- Вариант 1: наивное умножение (формула линейной алгебры) ---\n";
        t_naive = measure_seconds(gemm_naive, n, a.data(), b.data(), c_naive.data());
        mflops_naive = static_cast<double>(flops) / t_naive / 1e6;
        std::cout << "t = " << t_naive << " с,  p = " << mflops_naive << " MFlops\n\n";
    } else {
        std::cout << "--- Вариант 1: пропущен (--skip-naive) ---\n\n";
    }

    std::cout << "--- Вариант 2: cblas_zgemm (BLAS) ---\n";
#if defined(_WIN32) && !defined(LAB2_USE_MKL)
    openblas_set_num_threads(1);
    std::cout << "BLAS: OpenBLAS (1 поток для сопоставимого сравнения с OpenMP GEMM)\n";
#elif defined(LAB2_USE_MKL)
    std::cout << "BLAS: Intel MKL\n";
#endif
    const double t_mkl = measure_seconds(gemm_mkl, n, a.data(), b.data(), c_mkl.data());
    const double mflops_mkl = static_cast<double>(flops) / t_mkl / 1e6;
    std::cout << "t = " << t_mkl << " с,  p = " << mflops_mkl << " MFlops\n\n";

    std::cout << "--- Вариант 3: блочный алгоритм + OpenMP ---\n";
    const double t_opt = measure_seconds(gemm_optimized, n, a.data(), b.data(), c_opt.data());
    const double mflops_opt = static_cast<double>(flops) / t_opt / 1e6;
    const double ratio = (mflops_mkl > 0.0) ? (100.0 * mflops_opt / mflops_mkl) : 0.0;
    std::cout << "t = " << t_opt << " с,  p = " << mflops_opt << " MFlops\n";
    std::cout << "Производительность относительно MKL: " << ratio << "%\n\n";

    const double diff_full = max_diff(n, c_opt.data(), c_mkl.data());
    std::cout << "Полная проверка: |C_opt - C_mkl|_max = " << diff_full << "\n";

    std::cout << "\nСводка:\n";
    std::cout << std::setw(22) << "Метод" << std::setw(14) << "t, с" << std::setw(16) << "MFlops"
              << std::setw(14) << "% от MKL\n";
    if (!skip_naive) {
        std::cout << std::setw(22) << "Naive" << std::setw(14) << t_naive << std::setw(16)
                  << mflops_naive << std::setw(14) << (100.0 * mflops_naive / mflops_mkl) << "\n";
    }
    std::cout << std::setw(22) << "MKL zgemm" << std::setw(14) << t_mkl << std::setw(16)
              << mflops_mkl << std::setw(14) << "100.0\n";
    std::cout << std::setw(22) << "Blocked+OpenMP" << std::setw(14) << t_opt << std::setw(16)
              << mflops_opt << std::setw(14) << ratio << "\n";

    if (ratio < 30.0) {
        std::cerr << "Предупреждение: вариант 3 ниже 30% от MKL.\n";
        return 3;
    }

    return 0;
}

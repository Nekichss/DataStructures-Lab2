$ErrorActionPreference = "Stop"
$LabRoot = Split-Path -Parent $PSScriptRoot
$Dest = Join-Path $LabRoot "third_party"
$Zip = Join-Path $Dest "openblas.zip"
$Url = "https://github.com/OpenMathLib/OpenBLAS/releases/download/v0.3.28/OpenBLAS-0.3.28-x64.zip"

New-Item -ItemType Directory -Force -Path $Dest | Out-Null
if (-not (Test-Path $Zip)) {
    Write-Host "Downloading OpenBLAS..."
    Invoke-WebRequest -Uri $Url -OutFile $Zip -UseBasicParsing
}
Expand-Archive -Path $Zip -DestinationPath (Join-Path $Dest "openblas") -Force
Write-Host "OpenBLAS ready at lab2/third_party/openblas"

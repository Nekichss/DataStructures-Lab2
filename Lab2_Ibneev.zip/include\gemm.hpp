#pragma once

#include "matrix.hpp"

void gemm_naive(int n, const Complex* a, const Complex* b, Complex* c);
void gemm_mkl(int n, const Complex* a, const Complex* b, Complex* c);
void gemm_optimized(int n, const Complex* a, const Complex* b, Complex* c);
double max_diff(int n, const Complex* c1, const Complex* c2);

# Лабораторная работа №2 — умножение комплексных матриц

Умножение двух матриц `1024×1024` с элементами `std::complex<double>` тремя способами:

1. Наивный алгоритм (тройной цикл, `-O0`)
2. `cblas_zgemm` (Intel MKL)
3. Блочный алгоритм с OpenMP

## Требования

- CMake 3.16+
- Компилятор C++17 (MSVC или MinGW-w64)
- [Intel oneAPI Base Toolkit](https://www.intel.com/content/www/us/en/developer/tools/oneapi/base-toolkit-download.html) (компонент MKL)

## Сборка (Windows)

```powershell
# После установки oneAPI (путь может отличаться):
$env:ONEAPI_ROOT = "C:\Program Files (x86)\Intel\oneAPI"
cmake -B build -S lab2 -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

Исполняемый файл: `build\Release\lab2_matrix.exe` (MSVC) или `build\lab2_matrix.exe`.

## Запуск

```powershell
.\build\Release\lab2_matrix.exe
.\build\Release\lab2_matrix.exe --source formula
.\build\Release\lab2_matrix.exe --source file --file matrices.bin
.\build\Release\lab2_matrix.exe --n 128 --verify-only
```

Параметры:

| Параметр | Описание |
|----------|----------|
| `--n N` | Размер матрицы (по умолчанию 1024) |
| `--source random\|formula\|file` | Способ заполнения матриц |
| `--file path` | Бинарный файл с матрицами A и B |
| `--save path` | Сохранить сгенерированные A и B |
| `--verify-only` | Только проверка корректности на n≤128 |

Формулы оценки из задания:

- `c = 2·n³` операций
- `p = c / t · 10⁻⁶` MFlops

## Архив для сдачи

```powershell
.\lab2\scripts\make_submission.ps1
```

В zip входят исходники, PDF-отчёт и скриншоты/вывод консоли. Исполняемые файлы не включаются.

## Автор

Ибнеев Никита Дмитриевич, группа 090301-ПОВа-о25

$ErrorActionPreference = "Stop"
$LabRoot = Split-Path -Parent $PSScriptRoot
$OutZip = Join-Path $LabRoot "Lab2_Ibneev.zip"

if (Test-Path $OutZip) {
    Remove-Item $OutZip -Force
}

$TempDir = Join-Path $env:TEMP ("lab2_submission_" + [guid]::NewGuid().ToString())
New-Item -ItemType Directory -Path $TempDir | Out-Null

function Copy-TreeFiltered($Source, $Dest) {
    New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    Get-ChildItem -Path $Source -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring($Source.Length).TrimStart('\')
        if ($rel -match '\\build\\|\\out\\|\.exe$|\.obj$|\.o$|\.pdb$|\.ilk$') {
            return
        }
        $target = Join-Path $Dest $rel
        $targetDir = Split-Path $target -Parent
        if (-not (Test-Path $targetDir)) {
            New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
        }
        Copy-Item $_.FullName $target
    }
}

Copy-TreeFiltered (Join-Path $LabRoot "src") (Join-Path $TempDir "src")
Copy-TreeFiltered (Join-Path $LabRoot "include") (Join-Path $TempDir "include")
Copy-Item (Join-Path $LabRoot "CMakeLists.txt") (Join-Path $TempDir "CMakeLists.txt")
Copy-Item (Join-Path $LabRoot "README.md") (Join-Path $TempDir "README.md")

if (Test-Path (Join-Path $LabRoot "report\Report_Lab2.pdf")) {
    Copy-Item (Join-Path $LabRoot "report\Report_Lab2.pdf") (Join-Path $TempDir "Report_Lab2.pdf")
}

if (Test-Path (Join-Path $LabRoot "screenshots")) {
    Copy-TreeFiltered (Join-Path $LabRoot "screenshots") (Join-Path $TempDir "screenshots")
}

$ScriptsDest = Join-Path $TempDir "scripts"
New-Item -ItemType Directory -Force -Path $ScriptsDest | Out-Null
Get-ChildItem (Join-Path $LabRoot "scripts") -Filter "*.ps1" | Copy-Item -Destination $ScriptsDest
Get-ChildItem (Join-Path $LabRoot "scripts") -Filter "*.py" | Copy-Item -Destination $ScriptsDest

Compress-Archive -Path (Join-Path $TempDir "*") -DestinationPath $OutZip -Force
Remove-Item $TempDir -Recurse -Force

Write-Host "Архив создан: $OutZip"

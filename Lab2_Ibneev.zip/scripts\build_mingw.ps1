$ErrorActionPreference = "Stop"
$LabRoot = Split-Path -Parent $PSScriptRoot
$BuildDir = Join-Path $LabRoot "build"
$OpenBlas = Join-Path $LabRoot "third_party\openblas"

if (-not (Test-Path (Join-Path $OpenBlas "include\cblas.h"))) {
    Write-Host "OpenBLAS not found. Run: lab2/scripts/download_openblas.ps1"
    exit 1
}

$Gpp = "C:\Users\ibnee\gcc\bin\g++.exe"
if (-not (Test-Path $Gpp)) {
    $Gpp = "g++"
}

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null

$Include = Join-Path $LabRoot "include"
$ObInclude = Join-Path $OpenBlas "include"
$ObLib = Join-Path $OpenBlas "lib\libopenblas.dll.a"
$Out = Join-Path $BuildDir "lab2_matrix.exe"

$NaiveObj = Join-Path $BuildDir "naive_gemm.o"
& $Gpp -std=c++17 -O0 -I $Include -c (Join-Path $LabRoot "src\naive_gemm.cpp") -o $NaiveObj

$Objs = @($NaiveObj)
foreach ($src in @("matrix.cpp", "mkl_gemm.cpp", "optimized_gemm.cpp", "main.cpp")) {
    $obj = Join-Path $BuildDir ($src -replace '\.cpp$', '.o')
    & $Gpp -std=c++17 -O3 -fopenmp -I $Include -I $ObInclude -c (Join-Path $LabRoot "src\$src") -o $obj
    $Objs += $obj
}

& $Gpp -std=c++17 -O3 -fopenmp -o $Out @Objs $ObLib

$DllSrc = Join-Path $OpenBlas "bin\libopenblas.dll"
if (Test-Path $DllSrc) {
    Copy-Item $DllSrc $BuildDir -Force
}

Write-Host "Built: $Out"

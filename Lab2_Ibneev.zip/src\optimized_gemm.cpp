#include "gemm.hpp"

namespace {
constexpr int kBlock = 64;
}

void gemm_optimized(int n, const Complex* a, const Complex* b, Complex* c) {
    zero_matrix(n, c);

#pragma omp parallel for collapse(2) schedule(static)
    for (int ii = 0; ii < n; ii += kBlock) {
        for (int jj = 0; jj < n; jj += kBlock) {
            const int i_end = (ii + kBlock < n) ? ii + kBlock : n;
            const int j_end = (jj + kBlock < n) ? jj + kBlock : n;

            for (int kk = 0; kk < n; kk += kBlock) {
                const int k_end = (kk + kBlock < n) ? kk + kBlock : n;

                for (int i = ii; i < i_end; ++i) {
                    for (int k = kk; k < k_end; ++k) {
                        const Complex a_ik = mat_at(a, n, i, k);
                        for (int j = jj; j < j_end; ++j) {
                            mat_at(c, n, i, j) += a_ik * mat_at(b, n, k, j);
                        }
                    }
                }
            }
        }
    }
}

#include "gemm.hpp"

void gemm_naive(int n, const Complex* a, const Complex* b, Complex* c) {
    zero_matrix(n, c);
    for (int j = 0; j < n; ++j) {
        for (int i = 0; i < n; ++i) {
            Complex sum(0.0, 0.0);
            for (int k = 0; k < n; ++k) {
                sum += mat_at(a, n, i, k) * mat_at(b, n, k, j);
            }
            mat_at(c, n, i, j) = sum;
        }
    }
}

double max_diff(int n, const Complex* c1, const Complex* c2) {
    double max_val = 0.0;
    const std::size_t count = static_cast<std::size_t>(n) * static_cast<std::size_t>(n);
    for (std::size_t idx = 0; idx < count; ++idx) {
        const double d = std::abs(c1[idx] - c2[idx]);
        if (d > max_val) {
            max_val = d;
        }
    }
    return max_val;
}

#include "gemm.hpp"

#ifdef LAB2_USE_MKL
#include <mkl.h>
#else
#include <cblas.h>
#endif

void gemm_mkl(int n, const Complex* a, const Complex* b, Complex* c) {
    const Complex alpha(1.0, 0.0);
    const Complex beta(0.0, 0.0);

    cblas_zgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, n, n, n, &alpha, a, n, b, n,
                &beta, c, n);
}
